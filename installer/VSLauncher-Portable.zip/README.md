# VS Launcher (Portable Multi-Instance Visual Studio Code)

`Launcher.exe` is a lightweight, native Windows GUI manager for portable VS Code instances. It automatically detects, creates, organizes, launches, and updates portable VS Code instances and the core installation.

```text
vsinstances/
├── Launcher.exe             # VS Launcher (Runs as Administrator)
├── Launcher.cs              # Full C# source code
├── app.manifest             # UAC Administrator manifest
├── vscode/                  # Shared portable VS Code binaries & extensions
│   ├── Code.exe
│   └── data/
│       ├── user-data/       # Core portable user data
│       └── extensions/      # Central shared extensions directory
├── _template/               # Clean launcher script template
│   └── launch.bat
├── instance1/               # Instance 1
│   ├── launch.bat
│   └── instance.json
├── instance2/               # Instance 2
│   ├── launch.bat
│   └── instance.json
├── instance3/               # Instance 3
│   ├── launch.bat
│   └── instance.json
└── README.md
```

## Features

### 1. Floating Top-Right Header Summary
Floating directly on the right side of the black header bar:
- **Core Version & Update Status:** e.g., `VS Code v1.147.0  ● Up to date` or `● Update Available: vX.X.X`
- **Summary Metrics (slightly grey text):** `Extensions: 0 installed  •  Size: 1.09 GB`
- **Quick Actions:** `▶ Open Main` and `🔄 Update`
- **Missing Core Setup:** If `vscode\` or `Code.exe` is missing, the top right displays:
  - `VS Code Core: Not Installed`
  - `Portable installation missing in vscode\ folder`
  - A prominent green **`⬇ Install VS Code`** button to download and configure the official portable setup with one click.

### 2. Always Run as Administrator
- Embedded `requireAdministrator` manifest and programmatic elevation check ensure VS Launcher always runs with administrative privileges for managing files, portable directories, and desktop shortcuts.

### 3. Instance Management & Extension Isolation
- **Shared with Main:** Uses `vscode\data\extensions` to eliminate redundant disk usage.
- **Isolated (Empty):** Starts with a private, empty extensions directory.
- **Isolated (Copy from Main):** Clones current shared extensions and isolates future installs.
- **Profile Options:** Fresh profile or cloned from another instance.
- **Toolbar:** `▶ Launch`, `📁 Folder`, `🔗 Shortcut` (creates desktop shortcut with VS Code icon), `🗑️ Delete`, and `↻ Refresh`.
